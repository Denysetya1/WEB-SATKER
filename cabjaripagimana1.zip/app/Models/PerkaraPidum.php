<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;

class PerkaraPidum extends Model
{
    use HasFactory, SoftDeletes;
    protected $fillable = [
        'identitas_tersangka_id',
        'no_spdp',
        'file_path',
        'masuk_at'
    ];
    public function identitas_tersangka(): BelongsTo
    {
        return $this->belongsTo(IdentitasTersangka::class);
    }
    public function pidum_aktiviti(): HasMany
    {
        return $this->hasMany(PerkaraPidum::class);
    }
}
