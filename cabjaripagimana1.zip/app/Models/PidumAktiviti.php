<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Spatie\EloquentSortable\Sortable;
use Spatie\EloquentSortable\SortableTrait;

class PidumAktiviti extends Model implements Sortable
{
    use HasFactory, SortableTrait;

    protected $fillable = [
        'perkara_pidum_id',
        'tahapan_perkara_id',
        'administrasi_pidum_id',
        'user_id',
        'deadline',
        'file_path',
        'order_column',
        'keterangan',
        'revisi',
        'status',
    ];
    public function perkara_pidum(): BelongsTo
    {
        return $this->belongsTo(PerkaraPidum::class);
    }
    public function tahapan_perkara(): BelongsTo
    {
        return $this->belongsTo(TahapanPerkara::class);
    }
    public function administrasi_pidum(): BelongsTo
    {
        return $this->belongsTo(AdministrasiPidum::class);
    }
    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }
}
