<?php

namespace App\Filament\Pages;

use App\Enums\PidumAktivitisStatus;
use App\Filament\Widgets\PerkaraPidums;
use App\Models\PerkaraPidum;
use App\Models\PidumAktiviti;
use Filament\Actions\Action;
use Filament\Actions\Concerns\InteractsWithActions;
use Filament\Actions\Contracts\HasActions;
use Filament\Actions\CreateAction;
use Filament\Actions\EditAction;
use Filament\Forms;
use Filament\Infolists\Concerns\InteractsWithInfolists;
use Filament\Infolists\Contracts\HasInfolists;
use Filament\Infolists\Infolist;
use Filament\Support\Enums\ActionSize;
use Filament\Support\Enums\MaxWidth;
use Filament\Tables;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Mail\Markdown;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Jantinnerezo\LivewireAlert\LivewireAlert;
use Joaopaulolndev\FilamentPdfViewer\Forms\Components\PdfViewerField;
use Joaopaulolndev\FilamentPdfViewer\Infolists\Components\PdfViewerEntry;
use Livewire\Attributes\On;
use Mokhosh\FilamentKanban\Pages\KanbanBoard;

class PidumPerkarasKanbanBoard extends KanbanBoard implements HasActions, HasInfolists
{
    use LivewireAlert;
    use InteractsWithActions, InteractsWithInfolists;
    protected static string $model = PidumAktiviti::class;
    protected static string $statusEnum = PidumAktivitisStatus::class;
    protected static ?string $title = 'Perkara Pidum';
    // protected static string $recordTitleAttribute = 'keterangan';
    protected static ?string $navigationLabel = 'Perkara';
    protected static ?string $navigationGroup = 'Pidum';
    protected static ?int $navigationSort = 2;
    protected static ?string $slug = 'perkara-pidum';
    public bool $disableEditModal = true;
    protected string $editModalTitle = 'Edit Tugas';
    // protected string $editModalWidth = '2xl';
    protected string $editModalSaveButtonLabel = 'Simpan';
    protected string $editModalCancelButtonLabel = 'Batal';
    public $search, $upload = false, $fileTugas = [];

    #[On('refresh-Component')]
    public function refreshComponent()
    {
        $this->dispatch('$refresh');
    }
    public function getMaxContentWidth(): MaxWidth
    {
        return MaxWidth::Full;
    }
    protected function getHeaderWidgets(): array
    {
        return [
            PerkaraPidums::class
        ];
    }
    public function getHeaderWidgetsColumns(): int | array
    {
        return 1;
    }
    protected function getEditModalFormSchema(null|int $recordId): array
    {
        if($this->upload){
            return [
                Forms\Components\FileUpload::make('file_path')
                    ->label('File Tugas')
                    ->directory('file-tugas')
                    ->moveFiles()
                    ->downloadable()
                    ->uploadingMessage('Uploading File...')
                    ->acceptedFileTypes(['application/pdf']),
                // PdfViewerField::make('file_path')
                //     ->label('File Tugas')
                //     ->minHeight('40svh')
            ];
        } else {
            return [
                Forms\Components\Grid::make([
                    'default' => 12
                ])
                ->schema([
                    Forms\Components\Select::make('perkara_pidum_id')
                        ->label('Perkara')
                        ->allowHtml()
                        ->preload()
                        ->placeholder('Pilih Perkara')
                        ->required()
                        ->validationMessages([
                            'required' => 'Wajib Diisi.',
                        ])
                        // ->relationship(name: 'perkara_pidum', titleAttribute: 'no_spdp', ignoreRecord: true)
                        // ->createOptionForm(IdentitasTersangka::getForm())
                        ->getSearchResultsUsing(function (string $search) {
                            $this->search = $search;
                            $promosi = PerkaraPidum::where('no_spdp', 'like', "%{$search}%")
                            ->orWhereHas('identitas_tersangka', function ($query) {
                                $query->where('nama', 'like', "%{$this->search}%");
                            })
                            ->limit(50)->get();

                            return $promosi->mapWithKeys(function ($promo) {
                                  return [$promo->getKey() => static::getCleanOptionString($promo)];
                            })->toArray();
                        })
                        ->getOptionLabelUsing(function ($value): string {
                            $promo = PerkaraPidum::find($value);

                            return static::getCleanOptionString($promo);
                        })
                        ->native(false)
                        ->searchable()
                        ->columnSpan([
                            'default' => 12,
                        ]),
                    Forms\Components\Select::make('tahapan_perkara_id')
                        ->label('Tahap')
                        ->preload()
                        ->placeholder('Pilih Tahap')
                        ->required()
                        ->validationMessages([
                            'required' => 'Wajib Diisi.',
                        ])
                        ->relationship(name: 'tahapan_perkara', titleAttribute: 'tahap')
                        // ->createOptionForm(IdentitasTersangka::getForm())
                        ->native(false)
                        ->searchable()
                        ->columnSpan([
                            'sm' => 12,
                            'md' => 4,
                        ]),
                    Forms\Components\Select::make('administrasi_pidum_id')
                        ->label('Berkas')
                        ->preload()
                        ->placeholder('Pilih Tahap')
                        ->required()
                        ->validationMessages([
                            'required' => 'Wajib Diisi.',
                        ])
                        ->relationship(name: 'administrasi_pidum', titleAttribute: 'label')
                        // ->createOptionForm(IdentitasTersangka::getForm())
                        ->native(false)
                        ->searchable()
                        ->columnSpan([
                            'sm' => 12,
                            'md' => 4,
                        ]),
                    Forms\Components\DatePicker::make('deadline')
                        ->label('Tanggal Deadline Tugas')
                        ->required()
                        ->native(false)
                        ->columnSpan([
                            'sm' => 12,
                            'md' => 4,
                        ]),
                    Forms\Components\TextArea::make('keterangan')
                        ->label('Deskripsi Tugas')
                        ->required()
                        ->columnSpan([
                            'default' => 12,
                        ]),

                ])
            ];
        };
    }
    protected function getHeaderActions(): array
    {
        return [
            CreateAction::make()
                ->label('Tambah Tugas')
                ->color('info')
                ->model(PidumAktiviti::class)
                ->closeModalByClickingAway(false)
                ->modalHeading('Tambah Tugas')
                ->modalSubmitActionLabel('Tambah')
                ->form([
                    Forms\Components\Grid::make([
                        'default' => 12
                    ])
                    ->schema([
                        Forms\Components\Select::make('perkara_pidum_id')
                            ->label('Perkara')
                            ->allowHtml()
                            ->preload()
                            ->placeholder('Pilih Perkara')
                            ->required()
                            ->validationMessages([
                                'required' => 'Wajib Diisi.',
                            ])
                            // ->relationship(name: 'perkara_pidum', titleAttribute: 'no_spdp', ignoreRecord: true)
                            // ->createOptionForm(IdentitasTersangka::getForm())
                            ->getSearchResultsUsing(function (string $search) {
                                $this->search = $search;
                                $promosi = PerkaraPidum::where('no_spdp', 'like', "%{$search}%")
                                ->orWhereHas('identitas_tersangka', function ($query) {
                                    $query->where('nama', 'like', "%{$this->search}%");
                                })
                                ->limit(50)->get();

                                return $promosi->mapWithKeys(function ($promo) {
                                      return [$promo->getKey() => static::getCleanOptionString($promo)];
                                })->toArray();
                            })
                            ->getOptionLabelUsing(function ($value): string {
                                $promo = PerkaraPidum::find($value);

                                return static::getCleanOptionString($promo);
                            })
                            ->native(false)
                            ->searchable()
                            ->columnSpan([
                                'default' => 12,
                            ]),
                        Forms\Components\Select::make('tahapan_perkara_id')
                            ->label('Tahap')
                            ->preload()
                            ->placeholder('Pilih Tahap')
                            ->required()
                            ->validationMessages([
                                'required' => 'Wajib Diisi.',
                            ])
                            ->relationship(name: 'tahapan_perkara', titleAttribute: 'tahap', ignoreRecord: true)
                            // ->createOptionForm(IdentitasTersangka::getForm())
                            ->native(false)
                            ->searchable()
                            ->columnSpan([
                                'sm' => 12,
                                'md' => 4,
                            ]),
                        Forms\Components\Select::make('administrasi_pidum_id')
                            ->label('Berkas')
                            ->preload()
                            ->placeholder('Pilih Tahap')
                            ->required()
                            ->validationMessages([
                                'required' => 'Wajib Diisi.',
                            ])
                            ->relationship(name: 'administrasi_pidum', titleAttribute: 'label', ignoreRecord: true)
                            // ->createOptionForm(IdentitasTersangka::getForm())
                            ->native(false)
                            ->searchable()
                            ->columnSpan([
                                'sm' => 12,
                                'md' => 4,
                            ]),
                        Forms\Components\DatePicker::make('deadline')
                            ->label('Tanggal Deadline Tugas')
                            ->required()
                            ->native(false)
                            ->columnSpan([
                                'sm' => 12,
                                'md' => 4,
                            ]),
                        Forms\Components\TextArea::make('keterangan')
                            ->label('Deskripsi Tugas')
                            ->required()
                            ->columnSpan([
                                'default' => 12,
                            ]),

                    ])
                ])
        ];
    }
    protected function records(): Collection
    {
        return PidumAktiviti::ordered()->get();
    }
    public function onStatusChanged(int $recordId, string $status, array $fromOrderedIds, array $toOrderedIds): void
    {
        if (Auth::user()) {
        // if (Auth::user()->pegawai->bidang->deskripsi == 'Pidana Umum') {
            if ($status == PidumAktivitisStatus::Proses) {
                PidumAktiviti::find($recordId)->update(['status' => $status, 'user_id' => Auth::id()]);
                $this->alert('info', 'Tugas Sedang Di Buat', [
                    'position' => 'center',
                    'timer' => 3000,
                    'toast' => false,
                ]);
            } else {
                PidumAktiviti::find($recordId)->update(['status' => $status]);
                if($status == 'Belum'){
                    $this->alert('warning', 'Tugas Belum Di Buat', [
                        'position' => 'center',
                        'timer' => 3000,
                        'toast' => false,
                    ]);
                } elseif($status == 'Selesai'){
                    $this->alert('success', 'Tugas Telah Di Buat', [
                        'position' => 'center',
                        'timer' => 3000,
                        'toast' => false,
                    ]);
                } elseif($status == 'Revisi'){
                    $this->alert('warning', 'Tugas Ada Di Revisi', [
                        'position' => 'center',
                        'timer' => 3000,
                        'toast' => false,
                    ]);
                }
            }
            PidumAktiviti::setNewOrder($toOrderedIds);
        } else {
            $this->alert('error', 'Maaf Hanya Staff Pidum Yang Bisa Mengubah', [
                'position' => 'center',
                'timer' => 3000,
                'toast' => false,
            ]);
        }
    }

    public function onSortChanged(int $recordId, string $status, array $orderedIds): void
    {
        PidumAktiviti::setNewOrder($orderedIds);
    }

    public static function getCleanOptionString(Model $model): string
    {
        return
                view('partials.select-result')
                    ->with('no_spdp', $model?->no_spdp)
                    ->with('nama', $model?->identitas_tersangka->nama)
                    ->render()
        ;
    }
    public function editClicked(int $recordId): void
    {
        $this->editModalRecordId = $recordId;
        $this->upload = false;
        /**
         * todo - the following line is a hacky fix
         * figure why sometimes form schema is created before this
         * method when a RichText is present in the form schema
         **/
        $data = $this->getEloquentQuery()->find($recordId)->toArray();
        $this->form($this->form);
        $this->form->fill($data);

        $this->dispatch('open-modal', id: 'kanban--edit-record-modal2');
    }
    public function editModalFormSubmitted(): void
    {
        $this->editRecord($this->editModalRecordId, $this->form->getState(), $this->editModalFormState);

        $this->editModalRecordId = null;
        $this->form->fill();

        $this->dispatch('close-modal', id: 'kanban--edit-record-modal2');
        $this->alert('success', 'Tugas Berhasil Diedit', [
            'position' => 'center',
            'timer' => 3000,
            'toast' => false,
        ]);
    }
    public function uploadFileModalFormSubmitted(): void
    {
        $this->editRecord($this->editModalRecordId, $this->form->getState(), $this->editModalFormState);
        $this->editModalRecordId = null;
        $this->form->fill();

        $this->dispatch('close-modal', id: 'kanban--upload-file-modal');
        $this->alert('success', 'File Tugas Berhasil Diupload', [
            'position' => 'center',
            'timer' => 3000,
            'toast' => false,
        ]);
    }
    public function deleteAction(): Action
    {
        return Action::make('delete')
            ->label('')
            ->color('danger')
            ->iconButton()
            ->icon('heroicon-m-trash')
            ->size(ActionSize::Small)
            ->action(function (array $arguments) {
                $post = PidumAktiviti::find($arguments['record']);
                $post?->delete();
                $this->alert('success', 'Tugas Berhasil Dihapus', [
                    'position' => 'center',
                    'timer' => 3000,
                    'toast' => false,
                ]);
            })
            ->requiresConfirmation()
            ->modalHeading('Hapus Tugas')
            ->modalDescription('Anda Yakin Menghapus Tugas?')
            ->modalSubmitActionLabel('Ya, Hapus')
            ->modalCancelActionLabel('Batal');
    }
    public function uploadAction(): Action
    {
        return Action::make('upload')
            ->label('Upload Tugas')
            ->color('info')
            // ->iconButton()
            ->icon('heroicon-m-document')
            ->size(ActionSize::Small)
            ->action(function (array $arguments) {
                $this->editModalRecordId = $arguments['record'];
                $this->upload = true;
                /**
                 * todo - the following line is a hacky fix
                 * figure why sometimes form schema is created before this
                 * method when a RichText is present in the form schema
                 **/
                $data = $this->getEloquentQuery()->find($arguments)->toArray();
                $this->form($this->form);
                $this->form->fill($data);

                $this->dispatch('open-modal', id: 'kanban--upload-file-modal');
            });
    }
    public function viewUploadAction(): Action
    {
        return Action::make('viewUpload')
            ->label('Lihat Tugas')
            ->color('wisteria')
            // ->iconButton()
            ->icon('heroicon-m-document')
            ->size(ActionSize::Small)
            ->action(function (array $arguments) {
                /**
                 * todo - the following line is a hacky fix
                 * figure why sometimes form schema is created before this
                 * method when a RichText is present in the form schema
                 **/
                $data = $this->getEloquentQuery()->find($arguments)->toArray();
                // $data[0]['file_path'] = Storage::url($data[0]['file_path']);
                // dd($data);
                $this->fileTugas = $data[0];
                // return response()->download(
                //     $this->invoice->file_path, 'invoice.pdf'
                // );
                $this->dispatch('open-modal', id: 'kanban--view-file-modal');
            });
    }
    public function deleteUploadAction(): Action
    {
        return Action::make('deleteUpload')
            ->label('Delete File')
            ->color('danger')
            // ->iconButton()
            ->icon('heroicon-m-trash')
            ->size(ActionSize::Small)
            ->action(function (array $arguments) {
                $post = PidumAktiviti::find($arguments['record']);
                $data['file_path'] = null;
                $post->update($data);
                $this->alert('success', 'Tugas Berhasil Dihapus', [
                    'position' => 'center',
                    'timer' => 3000,
                    'toast' => false,
                ]);
            })
            ->requiresConfirmation()
            ->modalHeading('Hapus File Tugas')
            ->modalDescription('Anda Yakin Menghapus File Tugas?')
            ->modalSubmitActionLabel('Ya, Hapus')
            ->modalCancelActionLabel('Batal');
    }
    public function fileInfolist(Infolist $infolist): Infolist
    {
        return $infolist
            ->state($this->fileTugas)
            ->schema([
                PdfViewerEntry::make('file_path')
                    ->label('View the PDF')
                    ->minHeight('50svh')
                    // ->fileUrl(Storage::url('file-tugas/01J2AHK1Y1J9Z1AEWF8Y4GY2RF.pdf'))
            ]);
    }
}
