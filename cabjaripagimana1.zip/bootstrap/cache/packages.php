<?php return array (
  'andcarpi/laravel-popper' => 
  array (
    'providers' => 
    array (
      0 => 'andcarpi\\Popper\\PopperServiceProvider',
    ),
    'aliases' => 
    array (
      'Popper' => 'andcarpi\\Popper\\Facades\\Popper',
    ),
  ),
  'andrewdwallo/filament-selectify' => 
  array (
    'providers' => 
    array (
      0 => 'Wallo\\FilamentSelectify\\FilamentSelectifyServiceProvider',
    ),
  ),
  'anourvalar/eloquent-serialize' => 
  array (
    'aliases' => 
    array (
      'EloquentSerialize' => 'AnourValar\\EloquentSerialize\\Facades\\EloquentSerializeFacade',
    ),
  ),
  'awcodes/filament-badgeable-column' => 
  array (
    'providers' => 
    array (
      0 => 'Awcodes\\FilamentBadgeableColumn\\BadgeableColumnServiceProvider',
    ),
  ),
  'awcodes/filament-tiptap-editor' => 
  array (
    'providers' => 
    array (
      0 => 'FilamentTiptapEditor\\FilamentTiptapEditorServiceProvider',
    ),
  ),
  'aymanalhattami/filament-context-menu' => 
  array (
    'providers' => 
    array (
      0 => 'AymanAlhattami\\FilamentContextMenu\\FilamentContextMenuServiceProvider',
    ),
    'aliases' => 
    array (
      'Skeleton' => 'AymanAlhattami\\FilamentContextMenu\\Facades\\FilamentContextMenu',
    ),
  ),
  'aymanalhattami/filament-slim-scrollbar' => 
  array (
    'providers' => 
    array (
      0 => 'Aymanalhattami\\FilamentSlimScrollbar\\FilamentSlimScrollbarServiceProvider',
    ),
    'aliases' => 
    array (
      'FilamentSlimScrollbar' => 'Aymanalhattami\\FilamentSlimScrollbar\\FilamentSlimScrollbarFacade',
    ),
  ),
  'bezhansalleh/filament-exceptions' => 
  array (
    'providers' => 
    array (
      0 => 'BezhanSalleh\\FilamentExceptions\\FilamentExceptionsServiceProvider',
    ),
    'aliases' => 
    array (
      'FilamentExceptions' => 'BezhanSalleh\\FilamentExceptions\\Facades\\FilamentExceptions',
    ),
  ),
  'bezhansalleh/filament-shield' => 
  array (
    'providers' => 
    array (
      0 => 'BezhanSalleh\\FilamentShield\\FilamentShieldServiceProvider',
    ),
    'aliases' => 
    array (
      'FilamentShield' => 'BezhanSalleh\\FilamentShield\\Facades\\FilamentShield',
    ),
  ),
  'blade-ui-kit/blade-heroicons' => 
  array (
    'providers' => 
    array (
      0 => 'BladeUI\\Heroicons\\BladeHeroiconsServiceProvider',
    ),
  ),
  'blade-ui-kit/blade-icons' => 
  array (
    'providers' => 
    array (
      0 => 'BladeUI\\Icons\\BladeIconsServiceProvider',
    ),
  ),
  'filament/actions' => 
  array (
    'providers' => 
    array (
      0 => 'Filament\\Actions\\ActionsServiceProvider',
    ),
  ),
  'filament/filament' => 
  array (
    'providers' => 
    array (
      0 => 'Filament\\FilamentServiceProvider',
    ),
  ),
  'filament/forms' => 
  array (
    'providers' => 
    array (
      0 => 'Filament\\Forms\\FormsServiceProvider',
    ),
  ),
  'filament/infolists' => 
  array (
    'providers' => 
    array (
      0 => 'Filament\\Infolists\\InfolistsServiceProvider',
    ),
  ),
  'filament/notifications' => 
  array (
    'providers' => 
    array (
      0 => 'Filament\\Notifications\\NotificationsServiceProvider',
    ),
  ),
  'filament/support' => 
  array (
    'providers' => 
    array (
      0 => 'Filament\\Support\\SupportServiceProvider',
    ),
  ),
  'filament/tables' => 
  array (
    'providers' => 
    array (
      0 => 'Filament\\Tables\\TablesServiceProvider',
    ),
  ),
  'filament/widgets' => 
  array (
    'providers' => 
    array (
      0 => 'Filament\\Widgets\\WidgetsServiceProvider',
    ),
  ),
  'firefly/filament-blog' => 
  array (
    'providers' => 
    array (
      0 => 'Firefly\\FilamentBlog\\FilamentBlogServiceProvider',
    ),
  ),
  'intervention/image' => 
  array (
    'providers' => 
    array (
      0 => 'Intervention\\Image\\ImageServiceProvider',
    ),
    'aliases' => 
    array (
      'Image' => 'Intervention\\Image\\Facades\\Image',
    ),
  ),
  'jantinnerezo/livewire-alert' => 
  array (
    'providers' => 
    array (
      0 => 'Jantinnerezo\\LivewireAlert\\LivewireAlertServiceProvider',
    ),
    'aliases' => 
    array (
      'LivewireAlert' => 'Jantinnerezo\\LivewireAlert\\LivewireAlertFacade',
    ),
  ),
  'jaocero/activity-timeline' => 
  array (
    'providers' => 
    array (
      0 => 'JaOcero\\ActivityTimeline\\ActivityTimelineServiceProvider',
    ),
  ),
  'jaocero/radio-deck' => 
  array (
    'providers' => 
    array (
      0 => 'JaOcero\\RadioDeck\\RadioDeckServiceProvider',
    ),
  ),
  'jeffgreco13/filament-breezy' => 
  array (
    'providers' => 
    array (
      0 => 'Jeffgreco13\\FilamentBreezy\\FilamentBreezyServiceProvider',
    ),
    'aliases' => 
    array (
      'FilamentBreezy' => 'Jeffgreco13\\FilamentBreezy\\Facades\\FilamentBreezy',
    ),
  ),
  'joaopaulolndev/filament-pdf-viewer' => 
  array (
    'providers' => 
    array (
      0 => 'Joaopaulolndev\\FilamentPdfViewer\\FilamentPdfViewerServiceProvider',
    ),
    'aliases' => 
    array (
      'FilamentPdfViewer' => 'Joaopaulolndev\\FilamentPdfViewer\\Facades\\FilamentPdfViewer',
    ),
  ),
  'joshembling/image-optimizer' => 
  array (
    'providers' => 
    array (
      0 => 'Joshembling\\ImageOptimizer\\ImageOptimizerServiceProvider',
    ),
    'aliases' => 
    array (
      'ImageOptimizer' => 'Joshembling\\ImageOptimizer\\Facades\\ImageOptimizer',
    ),
  ),
  'kenepa/multi-widget' => 
  array (
    'providers' => 
    array (
      0 => 'Kenepa\\MultiWidget\\MultiWidgetServiceProvider',
    ),
  ),
  'kirschbaum-development/eloquent-power-joins' => 
  array (
    'providers' => 
    array (
      0 => 'Kirschbaum\\PowerJoins\\PowerJoinsServiceProvider',
    ),
  ),
  'lara-zeus/popover' => 
  array (
    'providers' => 
    array (
      0 => 'LaraZeus\\Popover\\PopoverServiceProvider',
    ),
  ),
  'laravel-notification-channels/telegram' => 
  array (
    'providers' => 
    array (
      0 => 'NotificationChannels\\Telegram\\TelegramServiceProvider',
    ),
  ),
  'laravel/sail' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Sail\\SailServiceProvider',
    ),
  ),
  'laravel/sanctum' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Sanctum\\SanctumServiceProvider',
    ),
  ),
  'laravel/tinker' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Tinker\\TinkerServiceProvider',
    ),
  ),
  'leandrocfe/filament-apex-charts' => 
  array (
    'providers' => 
    array (
      0 => 'Leandrocfe\\FilamentApexCharts\\FilamentApexChartsServiceProvider',
    ),
    'aliases' => 
    array (
      'FilamentApexCharts' => 'Leandrocfe\\FilamentApexCharts\\Facades\\FilamentApexCharts',
    ),
  ),
  'livewire/livewire' => 
  array (
    'providers' => 
    array (
      0 => 'Livewire\\LivewireServiceProvider',
    ),
    'aliases' => 
    array (
      'Livewire' => 'Livewire\\Livewire',
    ),
  ),
  'malzariey/filament-daterangepicker-filter' => 
  array (
    'providers' => 
    array (
      0 => 'Malzariey\\FilamentDaterangepickerFilter\\FilamentDaterangepickerFilterServiceProvider',
    ),
    'aliases' => 
    array (
      'FilamentDaterangepickerFilter' => 'Malzariey\\FilamentDaterangepickerFilter\\Facades\\FilamentDaterangepickerFilter',
    ),
  ),
  'mokhosh/filament-kanban' => 
  array (
    'providers' => 
    array (
      0 => 'Mokhosh\\FilamentKanban\\FilamentKanbanServiceProvider',
    ),
    'aliases' => 
    array (
      'FilamentKanban' => 'Mokhosh\\FilamentKanban\\Facades\\FilamentKanban',
    ),
  ),
  'nesbot/carbon' => 
  array (
    'providers' => 
    array (
      0 => 'Carbon\\Laravel\\ServiceProvider',
    ),
  ),
  'njxqlus/filament-progressbar' => 
  array (
    'providers' => 
    array (
      0 => 'Njxqlus\\FilamentProgressbar\\FilamentProgressbarServiceProvider',
    ),
    'aliases' => 
    array (
      'FilamentProgressbar' => 'Njxqlus\\FilamentProgressbar\\Facades\\FilamentProgressbar',
    ),
  ),
  'nunomaduro/collision' => 
  array (
    'providers' => 
    array (
      0 => 'NunoMaduro\\Collision\\Adapters\\Laravel\\CollisionServiceProvider',
    ),
  ),
  'nunomaduro/termwind' => 
  array (
    'providers' => 
    array (
      0 => 'Termwind\\Laravel\\TermwindServiceProvider',
    ),
  ),
  'propaganistas/laravel-phone' => 
  array (
    'providers' => 
    array (
      0 => 'Propaganistas\\LaravelPhone\\PhoneServiceProvider',
    ),
  ),
  'rappasoft/laravel-authentication-log' => 
  array (
    'providers' => 
    array (
      0 => 'Rappasoft\\LaravelAuthenticationLog\\LaravelAuthenticationLogServiceProvider',
    ),
  ),
  'ryangjchandler/blade-capture-directive' => 
  array (
    'providers' => 
    array (
      0 => 'RyanChandler\\BladeCaptureDirective\\BladeCaptureDirectiveServiceProvider',
    ),
    'aliases' => 
    array (
      'BladeCaptureDirective' => 'RyanChandler\\BladeCaptureDirective\\Facades\\BladeCaptureDirective',
    ),
  ),
  'simplesoftwareio/simple-qrcode' => 
  array (
    'providers' => 
    array (
      0 => 'SimpleSoftwareIO\\QrCode\\QrCodeServiceProvider',
    ),
    'aliases' => 
    array (
      'QrCode' => 'SimpleSoftwareIO\\QrCode\\Facades\\QrCode',
    ),
  ),
  'solution-forest/filament-simplelightbox' => 
  array (
    'providers' => 
    array (
      0 => 'SolutionForest\\FilamentSimpleLightBox\\FilamentSimpleLightBoxServiceProvider',
    ),
    'aliases' => 
    array (
      'FilamentSimpleLightBox' => 'SolutionForest\\FilamentSimpleLightBox\\Facades\\FilamentSimpleLightBox',
    ),
  ),
  'spatie/eloquent-sortable' => 
  array (
    'providers' => 
    array (
      0 => 'Spatie\\EloquentSortable\\EloquentSortableServiceProvider',
    ),
  ),
  'spatie/laravel-activitylog' => 
  array (
    'providers' => 
    array (
      0 => 'Spatie\\Activitylog\\ActivitylogServiceProvider',
    ),
  ),
  'spatie/laravel-ignition' => 
  array (
    'providers' => 
    array (
      0 => 'Spatie\\LaravelIgnition\\IgnitionServiceProvider',
    ),
    'aliases' => 
    array (
      'Flare' => 'Spatie\\LaravelIgnition\\Facades\\Flare',
    ),
  ),
  'spatie/laravel-permission' => 
  array (
    'providers' => 
    array (
      0 => 'Spatie\\Permission\\PermissionServiceProvider',
    ),
  ),
  'stevebauman/location' => 
  array (
    'providers' => 
    array (
      0 => 'Stevebauman\\Location\\LocationServiceProvider',
    ),
    'aliases' => 
    array (
      'Location' => 'Stevebauman\\Location\\Facades\\Location',
    ),
  ),
  'tapp/filament-authentication-log' => 
  array (
    'providers' => 
    array (
      0 => 'Tapp\\FilamentAuthenticationLog\\FilamentAuthenticationLogServiceProvider',
    ),
  ),
  'ysfkaya/filament-phone-input' => 
  array (
    'providers' => 
    array (
      0 => 'Ysfkaya\\FilamentPhoneInput\\FilamentPhoneInputServiceProvider',
    ),
  ),
  'z3d0x/filament-logger' => 
  array (
    'providers' => 
    array (
      0 => 'Z3d0X\\FilamentLogger\\FilamentLoggerServiceProvider',
    ),
    'aliases' => 
    array (
      'FilamentLogger' => 'Z3d0X\\FilamentLogger\\Facades\\FilamentLogger',
    ),
  ),
);