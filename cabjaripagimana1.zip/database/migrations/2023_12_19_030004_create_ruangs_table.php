<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('ruangs', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('kantor_id');
            $table->string('nama');
            $table->string('kode')->unique();
            $table->string('photo_path');
            $table->timestamps();
        });

        Schema::table('ruangs', function(Blueprint $table) {
            $table->foreign('kantor_id')->references('id')->on('kantors')->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('ruangs');
    }
};
