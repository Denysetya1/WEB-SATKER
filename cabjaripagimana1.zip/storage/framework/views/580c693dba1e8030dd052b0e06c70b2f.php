<h3 class="mb-2 px-4 font-semibold text-lg text-gray-400">
    <span class="text-primary-400">❖</span>
    <?php echo e($status['title']); ?>

    (<?php echo e(count($status['records'])); ?>)
</h3>
<?php /**PATH C:\laragon\www\cabjaripagimana\resources\views/vendor/filament-kanban/kanban-header.blade.php ENDPATH**/ ?>