<?php if (isset($component)) { $__componentOriginal166a02a7c5ef5a9331faf66fa665c256 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal166a02a7c5ef5a9331faf66fa665c256 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament-panels::components.page.index','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament-panels::page'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div x-data wire:ignore.self class="md:flex overflow-x-auto overflow-y-hidden gap-4 pb-4">
        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo $__env->make(static::$statusView, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->

        <div wire:ignore>
            <?php echo $__env->make(static::$scriptsView, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>

    <?php if (isset($component)) { $__componentOriginal9883514461f844754e23c96019785a21 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9883514461f844754e23c96019785a21 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament-kanban::components.edit-record-modal2','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament-kanban::edit-record-modal2'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9883514461f844754e23c96019785a21)): ?>
<?php $attributes = $__attributesOriginal9883514461f844754e23c96019785a21; ?>
<?php unset($__attributesOriginal9883514461f844754e23c96019785a21); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9883514461f844754e23c96019785a21)): ?>
<?php $component = $__componentOriginal9883514461f844754e23c96019785a21; ?>
<?php unset($__componentOriginal9883514461f844754e23c96019785a21); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginalb90173af1727dc0552a5f5f14754ba9f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb90173af1727dc0552a5f5f14754ba9f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament-kanban::components.upload-file-modal','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament-kanban::upload-file-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb90173af1727dc0552a5f5f14754ba9f)): ?>
<?php $attributes = $__attributesOriginalb90173af1727dc0552a5f5f14754ba9f; ?>
<?php unset($__attributesOriginalb90173af1727dc0552a5f5f14754ba9f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb90173af1727dc0552a5f5f14754ba9f)): ?>
<?php $component = $__componentOriginalb90173af1727dc0552a5f5f14754ba9f; ?>
<?php unset($__componentOriginalb90173af1727dc0552a5f5f14754ba9f); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginal59fdf0b8d0ab05694418d868f74ea257 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal59fdf0b8d0ab05694418d868f74ea257 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament-kanban::components.view-file-modal','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament-kanban::view-file-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal59fdf0b8d0ab05694418d868f74ea257)): ?>
<?php $attributes = $__attributesOriginal59fdf0b8d0ab05694418d868f74ea257; ?>
<?php unset($__attributesOriginal59fdf0b8d0ab05694418d868f74ea257); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal59fdf0b8d0ab05694418d868f74ea257)): ?>
<?php $component = $__componentOriginal59fdf0b8d0ab05694418d868f74ea257; ?>
<?php unset($__componentOriginal59fdf0b8d0ab05694418d868f74ea257); ?>
<?php endif; ?>
    
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal166a02a7c5ef5a9331faf66fa665c256)): ?>
<?php $attributes = $__attributesOriginal166a02a7c5ef5a9331faf66fa665c256; ?>
<?php unset($__attributesOriginal166a02a7c5ef5a9331faf66fa665c256); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal166a02a7c5ef5a9331faf66fa665c256)): ?>
<?php $component = $__componentOriginal166a02a7c5ef5a9331faf66fa665c256; ?>
<?php unset($__componentOriginal166a02a7c5ef5a9331faf66fa665c256); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\cabjaripagimana\resources\views/vendor/filament-kanban/kanban-board.blade.php ENDPATH**/ ?>