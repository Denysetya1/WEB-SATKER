<?php
    use Awcodes\FilamentBadgeableColumn\Enums\BadgeSize;
?>

<!--[if BLOCK]><![endif]--><?php if(! $isHidden()): ?>
    <?php
        $color = $getColor();

        $size = match ($size = $getSize()) {
            BadgeSize::ExtraSmall, 'xs' => 'xs',
            BadgeSize::Small, 'sm', null => 'sm',
            BadgeSize::Medium, 'base', 'md' => 'md',
            default => $size,
        };

        $badgeClasses = \Illuminate\Support\Arr::toCssClasses([
            "badgeable-column-badge",
            match ($shouldBePill()) {
                true => 'px-2 !rounded-full',
                default => null,
            },
            match ($getFontFamily(null)) {
                'sans' => 'font-sans',
                'serif' => 'font-serif',
                'mono' => 'font-mono',
                default => null,
            },
            match ($getWeight(null) ?? 'medium') {
                'thin' => 'font-thin',
                'extralight' => 'font-extralight',
                'light' => 'font-light',
                'medium' => 'font-medium',
                'semibold' => 'font-semibold',
                'bold' => 'font-bold',
                'extrabold' => 'font-extrabold',
                'black' => 'font-black',
                default => null,
            }
        ]);
    ?>

    <?php if (isset($component)) { $__componentOriginal986dce9114ddce94a270ab00ce6c273d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal986dce9114ddce94a270ab00ce6c273d = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament::components.badge','data' => ['class' => $badgeClasses,'color' => $color,'size' => $size]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament::badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($badgeClasses),'color' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($color),'size' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($size)]); ?><?php echo e($getLabel()); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal986dce9114ddce94a270ab00ce6c273d)): ?>
<?php $attributes = $__attributesOriginal986dce9114ddce94a270ab00ce6c273d; ?>
<?php unset($__attributesOriginal986dce9114ddce94a270ab00ce6c273d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal986dce9114ddce94a270ab00ce6c273d)): ?>
<?php $component = $__componentOriginal986dce9114ddce94a270ab00ce6c273d; ?>
<?php unset($__componentOriginal986dce9114ddce94a270ab00ce6c273d); ?>
<?php endif; ?>
<?php endif; ?><!--[if ENDBLOCK]><![endif]-->
<?php /**PATH C:\laragon\www\cabjaripagimana\vendor\awcodes\filament-badgeable-column\src\/../resources/views/components/badge.blade.php ENDPATH**/ ?>