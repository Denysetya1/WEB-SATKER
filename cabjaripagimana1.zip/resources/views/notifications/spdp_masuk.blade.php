*Hi Pidum!*

Ada SPDP Masuk dengan nomor *{{$data['no_spdp']}}*
A.N. Tersangka *{{$data['nama']}}*
Pada Tanggal *{{$data['masuk_at']}}*
