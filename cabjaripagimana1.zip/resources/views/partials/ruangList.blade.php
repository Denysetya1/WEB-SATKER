<div>
    @livewire(\App\Filament\Widgets\Ruangs::class)
</div>
